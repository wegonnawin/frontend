import React from 'react';

export default function ScoreBoard({ score }) {
  return (
    <p>
      Your score is {score}!
    </p>
  );
}