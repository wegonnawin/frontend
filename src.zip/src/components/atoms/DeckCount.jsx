import React from 'react';

export default function DeckCount({ deckCount }) {
  return (
    <p>
      {deckCount} Cards are left in the deck
    </p>
  );
}